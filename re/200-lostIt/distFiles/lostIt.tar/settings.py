DB = 'sqlite:///./secureNotes.db'
